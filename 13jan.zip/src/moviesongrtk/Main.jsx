import React from 'react'
import Movies from './Movies'
import Songs from './Songs'

function Main() {
    
  return (
    <div>
<button>Reset button</button> <br /><br /><br />
<Movies/>
<Songs/>

    </div>
  )
}

export default Main