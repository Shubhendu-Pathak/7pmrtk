import React from 'react'
import One from './UseReducerFolder/One'
import Two from './UseReducerFolder/Two'
import Main from './moviesongrtk/Main'

function App() {
  return (
    <div>
      {/* <One/> */}
      {/* <Two/> */}

      {/*redux toolkit  */}
<Main/>

    </div>
  )
}

export default App