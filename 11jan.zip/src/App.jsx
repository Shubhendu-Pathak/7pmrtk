import React from 'react'
import One from './UseReducerFolder/One'
import Two from './UseReducerFolder/Two'

function App() {
  return (
    <div>
      {/* <One/> */}
      <Two/>
    </div>
  )
}

export default App