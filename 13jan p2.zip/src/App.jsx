import React from 'react'
import One from './UseReducerFolder/One'
import Two from './UseReducerFolder/Two'
import Main from './moviesongrtk/Main'
import Main3 from './moviertk2/Main3'

function App() {
  return (
    <div>
      {/* <One/> */}
      {/* <Two/> */}

      {/*redux toolkit  */}
{/* <Main/> */}

{/* RTK revision */}
<Main3/>

    </div>
  )
}

export default App