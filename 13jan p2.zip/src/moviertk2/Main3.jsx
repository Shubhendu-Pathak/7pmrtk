import React from 'react'
import Songs from './Songs'
import Movies from './Movies'

function Main3() {
  return (
    <div>
        <button>Reset Button</button> <br /><br /><br />

           <Songs/>
           <Movies/>

    </div>
  )
}

export default Main3